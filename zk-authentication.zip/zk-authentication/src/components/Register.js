import React, { useState } from 'react';
import { get_pass_hash } from '../pkg/zk_wasm.js';
const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    const hashedPassword = await get_pass_hash(password);
    
    // Simulate saving to backend (local storage for this example)
    localStorage.setItem(username, hashedPassword);
    alert('Registration successful!');
  };

  return (
    <form onSubmit={handleRegister}>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <button type="submit">Register</button>
    </form>
  );
};

export default Register;
