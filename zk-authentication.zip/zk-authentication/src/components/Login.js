import React, { useState } from 'react';
import { generate_proof, verify_proof } from '../pkg/zk_wasm.js'; // Adjust this path to match your structure

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    console.log('Login function called');
  
    const storedHashedPassword = localStorage.getItem(username);
    if (!storedHashedPassword) {
      alert('Username does not exist.');
      return;
    }
  
    try {
      const proof = await generate_proof(username, password);
      const isVerified = verify_proof(proof, storedHashedPassword);
  
      if (isVerified) {
        alert('Login successful!');
      } else {
        alert('Login failed. Invalid credentials.');
      }
    } catch (error) {
      alert('An error occurred during login. Please try again.');
    }
  };
  

  return (
    <form onSubmit={handleLogin}>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;
